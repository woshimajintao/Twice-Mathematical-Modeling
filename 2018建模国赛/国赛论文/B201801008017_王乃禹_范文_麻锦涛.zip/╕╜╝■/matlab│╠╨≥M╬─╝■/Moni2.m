HU=[];
HT=[];
HTT=[];
HT1=[];
HT2=[];
HT3=[];
HT4=[];
%CNC�ӹ���ɵ�һ���������õ�ʱ��
T1=455;
T2=182;
%RGVΪCNC�����ϵ�ʱ��
To=27; %����CNC
Te=32; %ż��CNC
%RGV����ϴʱ��
T=25;
%RGV�ƶ�һ������������λ����ʱ��
t1=18; 
t2=32;
t3=46;
%CNC��ʱ��������
C=[inf,0,t1,t1,t2,t2,t3,t3;
   0,inf,t1,t1,t2,t2,t3,t3;
   t1,t1,inf,0,t1,t1,t2,t2;
   t1,t1,0,inf,t1,t1,t2,t2;
   t2,t2,t1,t1,inf,0,t1,t1;
   t2,t2,t1,t1,0,inf,t1,t1;
   t3,t3,t2,t2,t1,t1,inf,0;
   t3,t3,t2,t2,t1,t1,0,inf;];
R=C;
TC=[0,0,0,0,0,0,0,0];

sumt=0;
wait=0;
N=[0,0,0,0,0,0,0,0]; 
while sumt<=28800
%��1����
LO=1
N(LO)=1
TC(LO)=T1;
HT1=[HT1,sumt];
sumt=sumt+To;
%1-3
DO=3;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
HT1=[HT1,sumt];
sumt=sumt+To;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- To;
    end
end
LO=DO;
N(LO)=1
TC(LO)=T1;

%3-5
DO=5;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
HT1=[HT1,sumt];
sumt=sumt+To;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- To;
    end
end
LO=DO;
N(LO)=1
TC(LO)=T1;


%5-7
DO=7;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
HT1=[HT1,sumt];
sumt=sumt+To;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- To;
    end
end
LO=DO;
N(LO)=1
TC(LO)=T1;

%7-1
DO=1;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
sumt=sumt+TC(DO);
wait=wait+TC(DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- TC(DO);
    end
end
HT2=[HT2,sumt];
sumt=sumt+To;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- To;
    end
end
LO=DO;
N(LO)=1;
TC(LO)=T1;

%1-4
DO=4;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
HT3=[HT3,sumt];
sumt=sumt+Te;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- Te;
    end
end
LO=4;
N(LO)=2;
TC(LO)=T2;

%4-3
DO=3;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
sumt=sumt+TC(DO);
wait=wait+TC(DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- TC(DO);
    end
end

HT2=[HT2,sumt];
sumt=sumt+To;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- To;
    end
end
LO=DO;
N(LO)=1;
TC(LO)=T1;

%3-2
DO=2;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
HT3=[HT3,sumt];
sumt=sumt+Te;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- Te;
    end
end
LO=DO;
N(LO)=2;
TC(LO)=T2;

%2-5
DO=5;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
sumt=sumt+TC(DO);
wait=wait+TC(DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- TC(DO);
    end
end

HT2=[HT2,sumt];
sumt=sumt+To;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- To;
    end
end
LO=DO;
N(LO)=1;
TC(LO)=T1;

%5-6
DO=6;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
HT3=[HT3,sumt];
sumt=sumt+Te;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- Te;
    end
end
LO=DO;
N(LO)=2;
TC(LO)=T2;

%6-7
DO=7;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
sumt=sumt+TC(DO);
wait=wait+TC(DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- TC(DO);
    end
end

HT2=[HT2,sumt];
sumt=sumt+To;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- To;
    end
end
LO=DO;
N(LO)=1;
TC(LO)=T1;

%7-8
DO=8;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
HT3=[HT3,sumt];
sumt=sumt+Te;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- Te;
    end
end
LO=DO;
N(LO)=2;
TC(LO)=T2;

%8-4
DO=4;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
LO=DO;
sumt=sumt+TC(LO);
wait=wait+TC(DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- TC(LO);
    end
end

HT4=[HT4,sumt];
sumt=sumt+Te;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- Te;
    end
end
N(LO)=1;
TC(LO)=T1;
sumt=sumt+T;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- T;
    end
end

%4-2
DO=2;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
LO=DO;
sumt=sumt+TC(LO);
wait=wait+TC(DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- TC(LO);
    end
end

HT4=[HT4,sumt];
sumt=sumt+Te;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- Te;
    end
end
N(LO)=1;
TC(LO)=T1;
sumt=sumt+T;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- T;
    end
end
%2-6
DO=6;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
LO=DO;
sumt=sumt+TC(LO);
wait=wait+TC(DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- TC(LO);
    end
end

HT4=[HT4,sumt];
sumt=sumt+Te;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- Te;
    end
end
N(LO)=1;
TC(LO)=T1;
sumt=sumt+T;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- T;
    end
end
%6-8
DO=8;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
LO=DO;
sumt=sumt+TC(LO);
wait=wait+TC(DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- TC(LO);
    end
end

HT4=[HT4,sumt];
sumt=sumt+Te;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- Te;
    end
end
N(LO)=1;
TC(LO)=T1;
sumt=sumt+T;
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- T;
    end
end
%8-1
DO=1;
sumt=sumt+C(LO,DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- C(LO,DO);
    end
end
LO=DO;
sumt=sumt+TC(LO);
wait=wait+TC(DO);
for i=1:8
    if N(i)~=0
       TC(i)=TC(i)- TC(LO);
    end
end

end
HT1=HT1';
HT2=HT2';
HT3=HT3';
HT4=HT4';
wait;
P=28800-abs(wait);
P=P/28800











