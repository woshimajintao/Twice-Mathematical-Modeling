function [ fit ] = fitness( s,C,NIND )
%��Ӧ�Ⱥ���
f=[];
for i=1:NIND
    ff=0;
    p=[];
    pp=s(i,:);
    p(1:5)=pp(1:5);
    p(6)=pp(6);
    p(7)=pp(2);
    p(8)=pp(7);
    p(9)=pp(3);
    p(10)=pp(8);
    p(11)=pp(4);
    p(12)=pp(9);
    p;
    for j=1:11
        ff=ff+C(p(j),p(j+1));
    end
    f=[f;ff];
end
fit=1./f;


end

