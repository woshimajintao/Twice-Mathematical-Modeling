function [ z1,z2 ] = cro( s,seln )
%����
f_n=s(seln(1),:);
m_n=s(seln(2),:);
%�Ӵ�Ⱦɫ��1
p1=f_n;
p2=m_n;
d=f_n(2:4);
for i=1:3
    for j=1:9
        if p2(j)==d(i)
            p2(j)=0;
        end
    end
end
pp2=[];
for i=1:9
    if p2(i)>1
        pp2=[pp2,p2(i)];
    end
end
d;
pp2;
zz1=[d,pp2];
z1=[];
z1(1)=1;
z1(2:4)=zz1(1:3);
z1(5)=1;
z1(6)=zz1(4);
z1(7)=zz1(5);
z1(8)=zz1(6);
z1(9)=zz1(7);
z1;
%�Ӵ�Ⱦɫ��2
p1=f_n;
p2=m_n;
d=m_n(2:4);
for i=1:3
    for j=1:9
        if p1(j)==d(i)
            p1(j)=0;
        end
    end
end
pp1=[];
for i=1:9
    if p1(i)>1
        pp1=[pp1,p1(i)];
    end
end
pp1;
zz2=[d,pp1];
z2=[];
z2(1)=1;
z2(2:4)=zz2(1:3);
z2(5)=1;
z2(6)=zz2(4);
z2(7)=zz2(5);
z2(8)=zz2(6);
z2(9)=zz2(7);
z2;

end

